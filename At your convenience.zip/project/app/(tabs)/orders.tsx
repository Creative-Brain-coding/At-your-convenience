import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Package, Clock, CircleCheck as CheckCircle, Truck, MapPin, Phone, Star, Calendar } from 'lucide-react-native';
import { useState } from 'react';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue,
  withTiming,
  interpolate
} from 'react-native-reanimated';

export default function OrdersScreen() {
  const [activeTab, setActiveTab] = useState('current');
  const slideAnim = useSharedValue(0);

  const currentOrders = [
    {
      id: '12345',
      restaurant: 'Al-Sham Restaurant',
      items: ['Kabsa Rice', 'Grilled Chicken', 'Hummus'],
      status: 'preparing',
      estimatedTime: '25 min',
      location: 'Damascus, Syria',
      total: '45.00',
      driver: 'Ahmad Hassan',
      rating: 4.8,
    },
    {
      id: '12346',
      restaurant: 'Aleppo Sweets',
      items: ['Baklava', 'Ma\'amoul', 'Arabic Tea'],
      status: 'on_way',
      estimatedTime: '12 min',
      location: 'Aleppo, Syria',
      total: '28.50',
      driver: 'Sara Ahmed',
      rating: 4.9,
    },
  ];

  const pastOrders = [
    {
      id: '12340',
      restaurant: 'Homs Grill House',
      items: ['Mixed Grill', 'Tabbouleh', 'Fattoush'],
      status: 'delivered',
      deliveredAt: '2 hours ago',
      location: 'Homs, Syria',
      total: '52.75',
      rating: 5.0,
    },
    {
      id: '12341',
      restaurant: 'Lattakia Seafood',
      items: ['Grilled Fish', 'Rice Pilaf', 'Salad'],
      status: 'delivered',
      deliveredAt: '1 day ago',
      location: 'Lattakia, Syria',
      total: '38.25',
      rating: 4.7,
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'preparing':
        return <Clock size={20} color="#DAA520" />;
      case 'on_way':
        return <Truck size={20} color="#4ECDC4" />;
      case 'delivered':
        return <CheckCircle size={20} color="#4CAF50" />;
      default:
        return <Package size={20} color="#666666" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'preparing':
        return 'Preparing';
      case 'on_way':
        return 'On the way';
      case 'delivered':
        return 'Delivered';
      default:
        return 'Unknown';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'preparing':
        return '#DAA520';
      case 'on_way':
        return '#4ECDC4';
      case 'delivered':
        return '#4CAF50';
      default:
        return '#666666';
    }
  };

  const tabAnimation = useAnimatedStyle(() => ({
    transform: [
      {
        translateX: interpolate(
          slideAnim.value,
          [0, 1],
          [0, 120]
        )
      }
    ]
  }));

  const handleTabPress = (tab: string) => {
    setActiveTab(tab);
    slideAnim.value = withTiming(tab === 'current' ? 0 : 1, { duration: 300 });
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Your Orders</Text>
          <Text style={styles.headerSubtitle}>Track and manage your deliveries</Text>
        </View>

        {/* Tab Selector */}
        <View style={styles.tabContainer}>
          <View style={styles.tabBackground}>
            <Animated.View style={[styles.tabIndicator, tabAnimation]} />
            <TouchableOpacity 
              style={styles.tab}
              onPress={() => handleTabPress('current')}
            >
              <Text style={[
                styles.tabText, 
                activeTab === 'current' && styles.activeTabText
              ]}>
                Current Orders
              </Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.tab}
              onPress={() => handleTabPress('history')}
            >
              <Text style={[
                styles.tabText, 
                activeTab === 'history' && styles.activeTabText
              ]}>
                Order History
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Orders Content */}
        {activeTab === 'current' ? (
          <View style={styles.ordersContainer}>
            {currentOrders.length === 0 ? (
              <View style={styles.emptyState}>
                <Package size={64} color="#666666" />
                <Text style={styles.emptyStateTitle}>No Active Orders</Text>
                <Text style={styles.emptyStateSubtitle}>
                  Your current orders will appear here
                </Text>
              </View>
            ) : (
              currentOrders.map((order) => (
                <TouchableOpacity key={order.id} style={styles.orderCard}>
                  <LinearGradient
                    colors={['#1A1A1A', '#2A2A2A']}
                    style={styles.orderGradient}
                  >
                    {/* Order Header */}
                    <View style={styles.orderHeader}>
                      <View style={styles.orderInfo}>
                        <Text style={styles.restaurantName}>{order.restaurant}</Text>
                        <Text style={styles.orderId}>Order #{order.id}</Text>
                      </View>
                      <View style={[styles.statusBadge, { backgroundColor: getStatusColor(order.status) + '20' }]}>
                        {getStatusIcon(order.status)}
                        <Text style={[styles.statusText, { color: getStatusColor(order.status) }]}>
                          {getStatusText(order.status)}
                        </Text>
                      </View>
                    </View>

                    {/* Order Items */}
                    <View style={styles.orderItems}>
                      {order.items.map((item, index) => (
                        <Text key={index} style={styles.orderItem}>• {item}</Text>
                      ))}
                    </View>

                    {/* Order Details */}
                    <View style={styles.orderDetails}>
                      <View style={styles.orderDetailRow}>
                        <MapPin size={16} color="#DAA520" />
                        <Text style={styles.orderDetailText}>{order.location}</Text>
                      </View>
                      <View style={styles.orderDetailRow}>
                        <Clock size={16} color="#DAA520" />
                        <Text style={styles.orderDetailText}>Est. {order.estimatedTime}</Text>
                      </View>
                      {order.driver && (
                        <View style={styles.orderDetailRow}>
                          <Truck size={16} color="#DAA520" />
                          <Text style={styles.orderDetailText}>Driver: {order.driver}</Text>
                        </View>
                      )}
                    </View>

                    {/* Order Footer */}
                    <View style={styles.orderFooter}>
                      <Text style={styles.orderTotal}>${order.total}</Text>
                      <TouchableOpacity style={styles.trackButton}>
                        <LinearGradient
                          colors={['#DAA520', '#FFD700']}
                          style={styles.trackButtonGradient}
                        >
                          <Text style={styles.trackButtonText}>Track Order</Text>
                        </LinearGradient>
                      </TouchableOpacity>
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              ))
            )}
          </View>
        ) : (
          <View style={styles.ordersContainer}>
            {pastOrders.map((order) => (
              <TouchableOpacity key={order.id} style={styles.orderCard}>
                <LinearGradient
                  colors={['#0A0A0A', '#1A1A1A']}
                  style={styles.orderGradient}
                >
                  <View style={styles.orderGoldBorder} />
                  
                  {/* Order Header */}
                  <View style={styles.orderHeader}>
                    <View style={styles.orderInfo}>
                      <Text style={styles.restaurantName}>{order.restaurant}</Text>
                      <Text style={styles.orderId}>Order #{order.id}</Text>
                    </View>
                    <View style={styles.ratingContainer}>
                      <Star size={16} color="#DAA520" fill="#DAA520" />
                      <Text style={styles.ratingText}>{order.rating}</Text>
                    </View>
                  </View>

                  {/* Order Items */}
                  <View style={styles.orderItems}>
                    {order.items.map((item, index) => (
                      <Text key={index} style={styles.orderItem}>• {item}</Text>
                    ))}
                  </View>

                  {/* Order Details */}
                  <View style={styles.orderDetails}>
                    <View style={styles.orderDetailRow}>
                      <MapPin size={16} color="#DAA520" />
                      <Text style={styles.orderDetailText}>{order.location}</Text>
                    </View>
                    <View style={styles.orderDetailRow}>
                      <Calendar size={16} color="#DAA520" />
                      <Text style={styles.orderDetailText}>Delivered {order.deliveredAt}</Text>
                    </View>
                  </View>

                  {/* Order Footer */}
                  <View style={styles.orderFooter}>
                    <Text style={styles.orderTotal}>${order.total}</Text>
                    <TouchableOpacity style={styles.reorderButton}>
                      <Text style={styles.reorderButtonText}>Reorder</Text>
                    </TouchableOpacity>
                  </View>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A0A0A',
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  headerTitle: {
    fontSize: 32,
    color: '#FFFFFF',
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#CCCCCC',
    fontFamily: 'Inter-Regular',
  },
  tabContainer: {
    paddingHorizontal: 16,
    marginTop: 20,
    marginBottom: 24,
  },
  tabBackground: {
    backgroundColor: '#1A1A1A',
    borderRadius: 12,
    padding: 4,
    flexDirection: 'row',
    position: 'relative',
  },
  tabIndicator: {
    position: 'absolute',
    top: 4,
    left: 4,
    width: 120,
    height: 40,
    backgroundColor: '#DAA520',
    borderRadius: 8,
  },
  tab: {
    flex: 1,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabText: {
    fontSize: 14,
    color: '#CCCCCC',
    fontFamily: 'Inter-Medium',
  },
  activeTabText: {
    color: '#0A0A0A',
    fontFamily: 'Inter-SemiBold',
  },
  ordersContainer: {
    paddingHorizontal: 16,
    paddingBottom: 32,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 64,
  },
  emptyStateTitle: {
    fontSize: 20,
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateSubtitle: {
    fontSize: 16,
    color: '#CCCCCC',
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
  orderCard: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  orderGradient: {
    padding: 20,
    position: 'relative',
  },
  orderGoldBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: '#DAA520',
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  orderInfo: {
    flex: 1,
  },
  restaurantName: {
    fontSize: 18,
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  orderId: {
    fontSize: 14,
    color: '#CCCCCC',
    fontFamily: 'Inter-Regular',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 14,
    color: '#DAA520',
    fontFamily: 'Inter-SemiBold',
  },
  orderItems: {
    marginBottom: 16,
  },
  orderItem: {
    fontSize: 14,
    color: '#CCCCCC',
    fontFamily: 'Inter-Regular',
    marginBottom: 4,
  },
  orderDetails: {
    marginBottom: 16,
    gap: 8,
  },
  orderDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  orderDetailText: {
    fontSize: 14,
    color: '#FFFFFF',
    fontFamily: 'Inter-Regular',
  },
  orderFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  orderTotal: {
    fontSize: 20,
    color: '#DAA520',
    fontFamily: 'Inter-Bold',
  },
  trackButton: {
    borderRadius: 8,
    overflow: 'hidden',
  },
  trackButtonGradient: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  trackButtonText: {
    fontSize: 14,
    color: '#0A0A0A',
    fontFamily: 'Inter-SemiBold',
  },
  reorderButton: {
    borderWidth: 1,
    borderColor: '#DAA520',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  reorderButtonText: {
    fontSize: 14,
    color: '#DAA520',
    fontFamily: 'Inter-SemiBold',
  },
});