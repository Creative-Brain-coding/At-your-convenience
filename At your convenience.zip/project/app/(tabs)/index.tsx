import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MapPin, Clock, Star, Truck } from 'lucide-react-native';
import { useEffect, useRef } from 'react';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withTiming, 
  withRepeat,
  withSequence,
  interpolate
} from 'react-native-reanimated';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const fadeAnim = useSharedValue(0);
  const slideAnim = useSharedValue(-50);
  const pulseAnim = useSharedValue(1);

  useEffect(() => {
    fadeAnim.value = withTiming(1, { duration: 1000 });
    slideAnim.value = withTiming(0, { duration: 800 });
    pulseAnim.value = withRepeat(
      withSequence(
        withTiming(1.05, { duration: 1500 }),
        withTiming(1, { duration: 1500 })
      ),
      -1,
      true
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: fadeAnim.value,
    transform: [{ translateY: slideAnim.value }],
  }));

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseAnim.value }],
  }));

  const syrianGovernorates = [
    'Damascus', 'Aleppo', 'Homs', 'Hama', 'Lattakia', 'Tartous', 
    'Daraa', 'As-Suwayda', 'Quneitra', 'Idlib', 'Deir ez-Zor', 
    'Al-Hasakah', 'Ar-Raqqa', 'Rif Dimashq'
  ];

  const quickActions = [
    { title: 'Fast Delivery', icon: Truck, time: '15-30 min' },
    { title: 'Track Order', icon: MapPin, time: 'Live tracking' },
    { title: 'Best Rated', icon: Star, time: '4.8+ rating' },
    { title: '24/7 Service', icon: Clock, time: 'Always open' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <Animated.View style={[styles.header, animatedStyle]}>
          <LinearGradient
            colors={['#DAA520', '#FFD700', '#DAA520']}
            style={styles.gradientHeader}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.headerContent}>
              <Text style={styles.welcomeText}>Welcome to</Text>
              <Text style={styles.brandText}>At Your Convenience</Text>
              <Text style={styles.taglineText}>Luxury Delivery Across Syria</Text>
            </View>
          </LinearGradient>
        </Animated.View>

        {/* Location Banner */}
        <Animated.View style={[styles.locationBanner, pulseStyle]}>
          <LinearGradient
            colors={['#1A1A1A', '#2A2A2A']}
            style={styles.locationGradient}
          >
            <MapPin size={20} color="#DAA520" />
            <Text style={styles.locationText}>Delivering to all Syrian Governorates</Text>
          </LinearGradient>
        </Animated.View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.quickActionsGrid}>
            {quickActions.map((action, index) => (
              <TouchableOpacity key={index} style={styles.quickActionCard}>
                <LinearGradient
                  colors={['#1A1A1A', '#2A2A2A']}
                  style={styles.quickActionGradient}
                >
                  <action.icon size={24} color="#DAA520" />
                  <Text style={styles.quickActionTitle}>{action.title}</Text>
                  <Text style={styles.quickActionTime}>{action.time}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Governorates */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Available Locations</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.governoratesContainer}>
              {syrianGovernorates.map((governorate, index) => (
                <TouchableOpacity key={index} style={styles.governorateCard}>
                  <LinearGradient
                    colors={['#0A0A0A', '#1A1A1A']}
                    style={styles.governorateGradient}
                  >
                    <Text style={styles.governorateText}>{governorate}</Text>
                    <View style={styles.governorateBorder} />
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Featured Services */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Premium Services</Text>
          <View style={styles.servicesContainer}>
            <TouchableOpacity style={styles.serviceCard}>
              <LinearGradient
                colors={['#DAA520', '#FFD700']}
                style={styles.serviceGradient}
              >
                <Text style={styles.serviceTitle}>Express Delivery</Text>
                <Text style={styles.serviceDescription}>Get your order in 15 minutes</Text>
              </LinearGradient>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.serviceCard}>
              <LinearGradient
                colors={['#1A1A1A', '#2A2A2A']}
                style={styles.serviceGradient}
              >
                <View style={styles.serviceGoldBorder} />
                <Text style={styles.serviceTitle}>VIP Service</Text>
                <Text style={styles.serviceDescription}>Priority handling & tracking</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A0A0A',
  },
  header: {
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 20,
    overflow: 'hidden',
  },
  gradientHeader: {
    padding: 24,
  },
  headerContent: {
    alignItems: 'center',
  },
  welcomeText: {
    fontSize: 16,
    color: '#0A0A0A',
    fontFamily: 'Inter-Medium',
    marginBottom: 4,
  },
  brandText: {
    fontSize: 28,
    color: '#0A0A0A',
    fontFamily: 'Inter-Bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  taglineText: {
    fontSize: 14,
    color: '#1A1A1A',
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
  locationBanner: {
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
    overflow: 'hidden',
  },
  locationGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    justifyContent: 'center',
  },
  locationText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    marginLeft: 8,
  },
  section: {
    marginTop: 32,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 22,
    color: '#FFFFFF',
    fontFamily: 'Inter-Bold',
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  quickActionCard: {
    width: (width - 48) / 2,
    marginBottom: 12,
    borderRadius: 16,
    overflow: 'hidden',
  },
  quickActionGradient: {
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#DAA520',
  },
  quickActionTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginTop: 12,
    textAlign: 'center',
  },
  quickActionTime: {
    color: '#DAA520',
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    marginTop: 4,
    textAlign: 'center',
  },
  governoratesContainer: {
    flexDirection: 'row',
    paddingRight: 16,
  },
  governorateCard: {
    marginRight: 12,
    borderRadius: 12,
    overflow: 'hidden',
  },
  governorateGradient: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    position: 'relative',
  },
  governorateText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
  governorateBorder: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: '#DAA520',
  },
  servicesContainer: {
    gap: 16,
  },
  serviceCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  serviceGradient: {
    padding: 24,
    position: 'relative',
  },
  serviceGoldBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: '#DAA520',
  },
  serviceTitle: {
    fontSize: 20,
    color: '#FFFFFF',
    fontFamily: 'Inter-Bold',
    marginBottom: 8,
  },
  serviceDescription: {
    fontSize: 14,
    color: '#CCCCCC',
    fontFamily: 'Inter-Regular',
  },
});