import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { User, MapPin, CreditCard, Bell, Shield, CircleHelp as HelpCircle, LogOut, ChevronRight, Star, Gift, Settings } from 'lucide-react-native';
import { useState } from 'react';

export default function ProfileScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [locationEnabled, setLocationEnabled] = useState(true);

  const userStats = [
    { label: 'Total Orders', value: '142', icon: Gift },
    { label: 'Rating', value: '4.9', icon: Star },
    { label: 'Saved', value: '$324', icon: CreditCard },
  ];

  const menuItems = [
    {
      section: 'Account',
      items: [
        { title: 'Personal Information', icon: User, color: '#4ECDC4' },
        { title: 'Delivery Addresses', icon: MapPin, color: '#FF6B6B' },
        { title: 'Payment Methods', icon: CreditCard, color: '#45B7D1' },
      ]
    },
    {
      section: 'Preferences',
      items: [
        { title: 'Notifications', icon: Bell, color: '#96CEB4', hasSwitch: true, value: notificationsEnabled, onToggle: setNotificationsEnabled },
        { title: 'Location Services', icon: MapPin, color: '#FFEAA7', hasSwitch: true, value: locationEnabled, onToggle: setLocationEnabled },
        { title: 'App Settings', icon: Settings, color: '#DDA0DD' },
      ]
    },
    {
      section: 'Support',
      items: [
        { title: 'Help Center', icon: HelpCircle, color: '#98D8C8' },
        { title: 'Privacy & Security', icon: Shield, color: '#F7DC6F' },
      ]
    }
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <LinearGradient
            colors={['#DAA520', '#FFD700']}
            style={styles.profileGradient}
          >
            <View style={styles.avatarContainer}>
              <View style={styles.avatar}>
                <User size={40} color="#0A0A0A" strokeWidth={2} />
              </View>
            </View>
            <Text style={styles.userName}>Ahmed Al-Rashid</Text>
            <Text style={styles.userLocation}>Damascus, Syria</Text>
            <View style={styles.vipBadge}>
              <Text style={styles.vipBadgeText}>VIP MEMBER</Text>
            </View>
          </LinearGradient>
        </View>

        {/* User Stats */}
        <View style={styles.statsContainer}>
          {userStats.map((stat, index) => (
            <View key={index} style={styles.statCard}>
              <LinearGradient
                colors={['#1A1A1A', '#2A2A2A']}
                style={styles.statGradient}
              >
                <stat.icon size={24} color="#DAA520" />
                <Text style={styles.statValue}>{stat.value}</Text>
                <Text style={styles.statLabel}>{stat.label}</Text>
              </LinearGradient>
            </View>
          ))}
        </View>

        {/* Menu Sections */}
        {menuItems.map((section, sectionIndex) => (
          <View key={sectionIndex} style={styles.menuSection}>
            <Text style={styles.sectionTitle}>{section.section}</Text>
            <View style={styles.menuContainer}>
              {section.items.map((item, itemIndex) => (
                <TouchableOpacity key={itemIndex} style={styles.menuItem}>
                  <LinearGradient
                    colors={['#0A0A0A', '#1A1A1A']}
                    style={styles.menuItemGradient}
                  >
                    <View style={styles.menuItemLeft}>
                      <View style={[styles.menuIconContainer, { backgroundColor: item.color + '20' }]}>
                        <item.icon size={20} color={item.color} />
                      </View>
                      <Text style={styles.menuItemTitle}>{item.title}</Text>
                    </View>
                    <View style={styles.menuItemRight}>
                      {item.hasSwitch ? (
                        <Switch
                          value={item.value}
                          onValueChange={item.onToggle}
                          trackColor={{ false: '#333333', true: '#DAA520' }}
                          thumbColor={item.value ? '#FFD700' : '#666666'}
                        />
                      ) : (
                        <ChevronRight size={20} color="#666666" />
                      )}
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        {/* Logout Button */}
        <View style={styles.logoutContainer}>
          <TouchableOpacity style={styles.logoutButton}>
            <LinearGradient
              colors={['#1A1A1A', '#2A2A2A']}
              style={styles.logoutGradient}
            >
              <LogOut size={20} color="#FF4444" />
              <Text style={styles.logoutText}>Sign Out</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.appInfo}>
          <Text style={styles.appInfoText}>At Your Convenience v1.0.0</Text>
          <Text style={styles.appInfoSubtext}>Made with ❤️ for Syria</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A0A0A',
  },
  profileHeader: {
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 20,
    overflow: 'hidden',
  },
  profileGradient: {
    padding: 32,
    alignItems: 'center',
  },
  avatarContainer: {
    marginBottom: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: '#0A0A0A',
  },
  userName: {
    fontSize: 24,
    color: '#0A0A0A',
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  userLocation: {
    fontSize: 16,
    color: '#1A1A1A',
    fontFamily: 'Inter-Regular',
    marginBottom: 16,
  },
  vipBadge: {
    backgroundColor: '#0A0A0A',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
  },
  vipBadgeText: {
    color: '#DAA520',
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    letterSpacing: 1,
  },
  statsContainer: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginTop: 24,
    gap: 12,
  },
  statCard: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
  },
  statGradient: {
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#333333',
  },
  statValue: {
    fontSize: 20,
    color: '#FFFFFF',
    fontFamily: 'Inter-Bold',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#CCCCCC',
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
  menuSection: {
    marginTop: 32,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 18,
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 12,
  },
  menuContainer: {
    gap: 1,
  },
  menuItem: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
  },
  menuItemGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderWidth: 1,
    borderColor: '#333333',
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  menuItemTitle: {
    fontSize: 16,
    color: '#FFFFFF',
    fontFamily: 'Inter-Medium',
  },
  menuItemRight: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoutContainer: {
    marginTop: 32,
    paddingHorizontal: 16,
  },
  logoutButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  logoutGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderWidth: 1,
    borderColor: '#FF4444',
    gap: 12,
  },
  logoutText: {
    fontSize: 16,
    color: '#FF4444',
    fontFamily: 'Inter-SemiBold',
  },
  appInfo: {
    alignItems: 'center',
    paddingVertical: 32,
    paddingHorizontal: 16,
  },
  appInfoText: {
    fontSize: 14,
    color: '#666666',
    fontFamily: 'Inter-Regular',
    marginBottom: 4,
  },
  appInfoSubtext: {
    fontSize: 12,
    color: '#DAA520',
    fontFamily: 'Inter-Regular',
  },
});