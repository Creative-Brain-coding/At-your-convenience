import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  Utensils, 
  ShoppingCart, 
  Pill, 
  Shirt, 
  Smartphone, 
  Flower, 
  Book, 
  Car,
  Search
} from 'lucide-react-native';
import { useState } from 'react';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue,
  withTiming,
  withSpring
} from 'react-native-reanimated';

const { width } = Dimensions.get('window');

export default function CategoriesScreen() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const scaleAnim = useSharedValue(1);

  const categories = [
    { id: 'food', title: 'Food & Dining', icon: Utensils, color: '#FF6B6B', items: 245 },
    { id: 'grocery', title: 'Grocery', icon: ShoppingCart, color: '#4ECDC4', items: 189 },
    { id: 'pharmacy', title: 'Pharmacy', icon: Pill, color: '#45B7D1', items: 156 },
    { id: 'fashion', title: 'Fashion', icon: Shirt, color: '#96CEB4', items: 312 },
    { id: 'electronics', title: 'Electronics', icon: Smartphone, color: '#FFEAA7', items: 198 },
    { id: 'flowers', title: 'Flowers & Gifts', icon: Flower, color: '#DDA0DD', items: 89 },
    { id: 'books', title: 'Books & Media', icon: Book, color: '#98D8C8', items: 134 },
    { id: 'automotive', title: 'Automotive', icon: Car, color: '#F7DC6F', items: 76 },
  ];

  const handleCategoryPress = (categoryId: string) => {
    setSelectedCategory(categoryId);
    scaleAnim.value = withSpring(0.95, {}, () => {
      scaleAnim.value = withSpring(1);
    });
  };

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scaleAnim.value }],
  }));

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Categories</Text>
          <Text style={styles.headerSubtitle}>Discover what you need</Text>
          
          {/* Search Bar */}
          <TouchableOpacity style={styles.searchContainer}>
            <LinearGradient
              colors={['#1A1A1A', '#2A2A2A']}
              style={styles.searchGradient}
            >
              <Search size={20} color="#DAA520" />
              <Text style={styles.searchPlaceholder}>Search categories...</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Categories Grid */}
        <View style={styles.categoriesContainer}>
          <Text style={styles.sectionTitle}>All Categories</Text>
          <View style={styles.categoriesGrid}>
            {categories.map((category, index) => (
              <Animated.View 
                key={category.id} 
                style={[
                  animatedStyle,
                  selectedCategory === category.id && styles.selectedCategoryContainer
                ]}
              >
                <TouchableOpacity 
                  style={styles.categoryCard}
                  onPress={() => handleCategoryPress(category.id)}
                >
                  <LinearGradient
                    colors={['#1A1A1A', '#2A2A2A']}
                    style={styles.categoryGradient}
                  >
                    <View style={[styles.iconContainer, { backgroundColor: category.color + '20' }]}>
                      <category.icon size={32} color={category.color} strokeWidth={2} />
                    </View>
                    <Text style={styles.categoryTitle}>{category.title}</Text>
                    <Text style={styles.categoryItems}>{category.items} items</Text>
                    <View style={[styles.categoryBorder, { backgroundColor: category.color }]} />
                  </LinearGradient>
                </TouchableOpacity>
              </Animated.View>
            ))}
          </View>
        </View>

        {/* Popular This Week */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Popular This Week</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.popularContainer}>
              {categories.slice(0, 4).map((category, index) => (
                <TouchableOpacity key={index} style={styles.popularCard}>
                  <LinearGradient
                    colors={['#DAA520', '#FFD700']}
                    style={styles.popularGradient}
                  >
                    <category.icon size={24} color="#0A0A0A" strokeWidth={2.5} />
                    <Text style={styles.popularTitle}>{category.title}</Text>
                    <View style={styles.popularBadge}>
                      <Text style={styles.popularBadgeText}>HOT</Text>
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Premium Services */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Premium Services</Text>
          <View style={styles.premiumContainer}>
            <TouchableOpacity style={styles.premiumCard}>
              <LinearGradient
                colors={['#0A0A0A', '#1A1A1A']}
                style={styles.premiumGradient}
              >
                <View style={styles.premiumGoldBorder} />
                <Text style={styles.premiumTitle}>VIP Delivery</Text>
                <Text style={styles.premiumDescription}>
                  Skip the queue with our premium delivery service
                </Text>
                <View style={styles.premiumFeatures}>
                  <Text style={styles.premiumFeature}>• Priority handling</Text>
                  <Text style={styles.premiumFeature}>• Real-time tracking</Text>
                  <Text style={styles.premiumFeature}>• 15-min delivery</Text>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A0A0A',
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  headerTitle: {
    fontSize: 32,
    color: '#FFFFFF',
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#CCCCCC',
    fontFamily: 'Inter-Regular',
    marginBottom: 20,
  },
  searchContainer: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  searchGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderWidth: 1,
    borderColor: '#333333',
  },
  searchPlaceholder: {
    color: '#666666',
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    marginLeft: 12,
  },
  categoriesContainer: {
    paddingHorizontal: 16,
    marginTop: 24,
  },
  sectionTitle: {
    fontSize: 22,
    color: '#FFFFFF',
    fontFamily: 'Inter-Bold',
    marginBottom: 16,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  selectedCategoryContainer: {
    transform: [{ scale: 0.98 }],
  },
  categoryCard: {
    width: (width - 48) / 2,
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  categoryGradient: {
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#333333',
    position: 'relative',
  },
  iconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  categoryTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    textAlign: 'center',
    marginBottom: 4,
  },
  categoryItems: {
    color: '#CCCCCC',
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
  categoryBorder: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 3,
  },
  section: {
    marginTop: 32,
    paddingHorizontal: 16,
  },
  popularContainer: {
    flexDirection: 'row',
    paddingRight: 16,
  },
  popularCard: {
    width: 140,
    marginRight: 12,
    borderRadius: 12,
    overflow: 'hidden',
  },
  popularGradient: {
    padding: 16,
    alignItems: 'center',
    position: 'relative',
  },
  popularTitle: {
    color: '#0A0A0A',
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    textAlign: 'center',
    marginTop: 8,
  },
  popularBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#FF4444',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  popularBadgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontFamily: 'Inter-Bold',
  },
  premiumContainer: {
    marginBottom: 32,
  },
  premiumCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  premiumGradient: {
    padding: 24,
    position: 'relative',
  },
  premiumGoldBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: '#DAA520',
  },
  premiumTitle: {
    fontSize: 20,
    color: '#DAA520',
    fontFamily: 'Inter-Bold',
    marginBottom: 8,
  },
  premiumDescription: {
    fontSize: 16,
    color: '#FFFFFF',
    fontFamily: 'Inter-Regular',
    marginBottom: 16,
  },
  premiumFeatures: {
    gap: 8,
  },
  premiumFeature: {
    fontSize: 14,
    color: '#CCCCCC',
    fontFamily: 'Inter-Regular',
  },
});